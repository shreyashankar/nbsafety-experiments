#include "testlib.h"
#include <iostream>

using namespace std;

std::string gen_brackets(int pairs, int depth) {
    if (pairs == 0)
        return "";

    int free_pairs = pairs - depth;
    if (free_pairs == 0) {
        char opening = ' ', closing = ' ';
        switch (rnd.next(3)) {
            case 0: { opening = '('; closing = ')'; } break;
            case 1: { opening = '['; closing = ']'; } break;
            case 2: { opening = '{'; closing = '}'; } break;
        }
        return opening + gen_brackets(pairs - 1, std::max(1, depth - 1)) + closing;
    }

    int main_pairs = rnd.next(free_pairs) + depth;
    int main_depth = depth;
    std::string main = gen_brackets(main_pairs, main_depth);

    int sub_pairs = pairs - main_pairs;
    int sub_depth = std::min(sub_pairs, 1 + rnd.next(0, depth));
    std::string sub = gen_brackets(sub_pairs, sub_depth);

    return rnd.next(2) ? main + sub : sub + main;
}

std::string gen_noise(std::string brackets, int noise) {
    for (int i = 0; i < noise; ++i) {
        int position = rnd.next(brackets.length() + 1);
        char bracket = ' ';
        switch (rnd.next(6)) {
            case 0: bracket = '('; break;
            case 1: bracket = ')'; break;
            case 2: bracket = '['; break;
            case 3: bracket = ']'; break;
            case 4: bracket = '{'; break;
            case 5: bracket = '}'; break;
        }
        brackets = brackets.substr(0, position) + bracket + brackets.substr(position, brackets.length());
    }
    return brackets;
}

std::string gen_text(std::string brackets, int length) {
    std::vector <std::string> parts(brackets.length() + 1, "");
    int left = length - brackets.length();
    for (int i = 0; i < left; ++i) {
        int part = rnd.next(parts.size());
        parts[part] += rnd.next("[a-zA-Z0-9.,:;!?]");
    }

    std::string text = parts[0];
    for (int i = 0; i < brackets.length(); ++i)
        text += brackets[i] + parts[i + 1];
    return text;
}

int main(int argc, char **argv) {
    registerGen(argc, argv, 1);

    int pairs = atoi(argv[1]);
    int depth = atoi(argv[2]);
    int noise = atoi(argv[3]);
    int length = atoi(argv[4]);

    std::string brackets = gen_text(gen_noise(gen_brackets(pairs, depth), noise), length);
    std::cout << brackets << std::endl;

    return 0;
}

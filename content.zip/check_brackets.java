import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;

class Bracket {
    Bracket(int type, int position) {
        this.type = type;
        this.position = position;
    }

    boolean Match(int c) {
        if (this.type == '[' && c == ']')
            return true;
        if (this.type == '{' && c == '}')
            return true;
        if (this.type == '(' && c == ')')
            return true;
        return false;
    }

    int type;
    int position;
}

class check_brackets {
    public static void main(String[] args) throws IOException {
        InputStreamReader input_stream = new InputStreamReader(System.in);
        BufferedReader reader = new BufferedReader(input_stream);
        String text = reader.readLine();

        ArrayList<Bracket> opening_brackets_stack = new ArrayList<Bracket>();
        for (int position = 0; position < text.length(); ++position) {
            int next = text.charAt(position);

            if (next == '(' || next == '[' || next == '{') {
                // Process opening bracket, write your code here
            }

            if (next == ')' || next == ']' || next == '}') {
                // Process closing bracket, write your code here
            }
        }

        // Printing answer, write your code here
    }
}

#include "testlib.h"
#include <cstring>

int main() {
    registerValidation();

    std::string test = inf.readLine();
    ensuref(test.length() <= 100000, "Check line length");
    
    for (int i = 0; i < test.length(); ++i) {
        char c = test[i];
        
        if ('a' <= c && c <= 'z')
            continue;
        if ('A' <= c && c <= 'Z')
            continue;
        if ('0' <= c && c <= '9')
            continue;
        ensuref(strchr(".,:;!?()[]{}", c) != 0, "File contains forbidden symbols.");
    }

    inf.readEof();
}
